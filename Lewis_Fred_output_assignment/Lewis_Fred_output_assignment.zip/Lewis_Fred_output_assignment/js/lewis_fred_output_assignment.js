// Fred-Curtis Lewis SDI Section 1 05 June 2015

var myFavoritePlaceOnEarth;
myFavoritePlaceOnEarth = "Norway It is so beautiful";

var speaksFourLanguages = true;  // Assigning a Boolean value

var firstLanguage = "Norwegian"; // Assigning a String value

var secondLanguage = "English"; // Assigning a String value

var thirdLanguage = "Korean"; // Assigning a String Value

var fourthLanguage = "German"; // Assigning a String Value

var countriesVisited = 33; // Assigning a Number Value


